import type { LucideIcon } from "lucide-react";
import type { SdgMode } from "@/lib/types";

type ModeCardProps = {
  mode: SdgMode;
  title: string;
  sdg: string;
  description: string;
  icon: LucideIcon;
  active: boolean;
  onClick: (mode: SdgMode) => void;
};

export function ModeCard({ mode, title, sdg, description, icon: Icon, active, onClick }: ModeCardProps) {
  return (
    <button
      type="button"
      onClick={() => onClick(mode)}
      className={`safe-card rounded-3xl p-5 text-left transition duration-200 hover:-translate-y-1 hover:border-rose-400/60 ${
        active ? "border-rose-400 shadow-glow" : "border-white/10"
      }`}
    >
      <div className="mb-4 flex items-center justify-between">
        <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-orange-100">{sdg}</span>
        <span className="rounded-2xl bg-rose-500/20 p-3 text-rose-200">
          <Icon size={22} />
        </span>
      </div>
      <h3 className="text-xl font-bold text-white">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-orange-50/75">{description}</p>
    </button>
  );
}

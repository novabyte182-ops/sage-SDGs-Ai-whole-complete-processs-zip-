import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabase-admin";
import type { DashboardMetrics } from "@/lib/types";

export const dynamic = "force-dynamic";

const fallbackMetrics: DashboardMetrics = {
  totalInteractions: 36,
  learnSessions: 14,
  mindcareSessions: 9,
  waterReports: 13,
  weeklyActivity: [
    { day: "Mon", interactions: 4 },
    { day: "Tue", interactions: 7 },
    { day: "Wed", interactions: 5 },
    { day: "Thu", interactions: 8 },
    { day: "Fri", interactions: 6 },
    { day: "Sat", interactions: 3 },
    { day: "Sun", interactions: 3 }
  ],
  modeBreakdown: [
    { name: "Learn", value: 14 },
    { name: "MindCare", value: 9 },
    { name: "AquaLife", value: 13 }
  ]
};

export async function GET() {
  const supabase = getSupabaseAdmin();

  if (!supabase) {
    return NextResponse.json({ ok: true, source: "demo", data: fallbackMetrics });
  }

  const { count: totalInteractions } = await supabase
    .from("interactions")
    .select("id", { count: "exact", head: true });

  const { count: learnSessions } = await supabase
    .from("interactions")
    .select("id", { count: "exact", head: true })
    .eq("mode", "learn");

  const { count: mindcareSessions } = await supabase
    .from("interactions")
    .select("id", { count: "exact", head: true })
    .eq("mode", "mindcare");

  const { count: waterReports } = await supabase
    .from("water_reports")
    .select("id", { count: "exact", head: true });

  const metrics: DashboardMetrics = {
    ...fallbackMetrics,
    totalInteractions: totalInteractions ?? 0,
    learnSessions: learnSessions ?? 0,
    mindcareSessions: mindcareSessions ?? 0,
    waterReports: waterReports ?? 0,
    modeBreakdown: [
      { name: "Learn", value: learnSessions ?? 0 },
      { name: "MindCare", value: mindcareSessions ?? 0 },
      { name: "AquaLife", value: waterReports ?? 0 }
    ]
  };

  return NextResponse.json({ ok: true, source: "supabase", data: metrics });
}

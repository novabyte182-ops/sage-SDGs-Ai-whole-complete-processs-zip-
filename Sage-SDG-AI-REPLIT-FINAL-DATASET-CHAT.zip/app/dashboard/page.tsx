import Link from "next/link";
import { ArrowLeft, Database, ShieldCheck } from "lucide-react";
import { DashboardCharts } from "@/components/DashboardCharts";

export default function DashboardPage() {
  return (
    <main className="min-h-screen px-5 py-8 text-orange-50 md:px-8">
      <section className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-orange-100/70 hover:text-white">
              <ArrowLeft size={16} /> Back to agent
            </Link>
            <h1 className="mt-3 text-4xl font-black text-white">Sage SDG AI Dashboard</h1>
            <p className="mt-3 max-w-2xl leading-7 text-orange-50/75">
              This dashboard shows platform activity. When Supabase environment variables are added, it reads live database counts. Without Supabase, it shows safe demo metrics so deployment still works.
            </p>
          </div>
          <div className="flex gap-3">
            <div className="safe-card rounded-2xl p-4 text-sm text-orange-50/80">
              <Database className="mb-2 text-rose-200" /> Supabase-ready
            </div>
            <div className="safe-card rounded-2xl p-4 text-sm text-orange-50/80">
              <ShieldCheck className="mb-2 text-emerald-200" /> Safety-first
            </div>
          </div>
        </div>

        <DashboardCharts />
      </section>
    </main>
  );
}

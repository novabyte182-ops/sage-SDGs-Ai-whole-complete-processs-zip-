"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Bot, Brain, Droplets, GraduationCap, Send, ShieldCheck, Sparkles, UserRound } from "lucide-react";
import { AgentResponseCard } from "@/components/AgentResponseCard";
import { ModeCard } from "@/components/ModeCard";
import { WaterReportForm } from "@/components/WaterReportForm";
import type { AgentResponse, SdgMode } from "@/lib/types";

const modes = [
  {
    mode: "learn" as const,
    title: "Learn Mode",
    sdg: "SDG 4",
    description: "Clear explanations, study plans, quizzes, and progress-building guidance.",
    icon: GraduationCap
  },
  {
    mode: "mindcare" as const,
    title: "MindCare Mode",
    sdg: "SDG 3",
    description: "Dataset-informed reflection, breathing, burnout/stress support, and safety escalation.",
    icon: Brain
  },
  {
    mode: "water" as const,
    title: "AquaLife Mode",
    sdg: "SDG 6 + SDG 3",
    description: "Water pollution risk, country-level clean-water action, symptoms, and reporting workflows.",
    icon: Droplets
  }
];

const placeholders: Record<SdgMode, string> = {
  learn: "Example: Explain SDG 6 and make a short quiz for me.",
  mindcare: "Example: I feel stressed and exhausted before my presentation. Help me calm down safely.",
  water: "Example: How can a country reduce water pollution and protect people from unsafe drinking water?"
};

type ChatItem = {
  id: string;
  mode: SdgMode;
  userMessage: string;
  response: AgentResponse;
};

function formatAssistantBubble(response: AgentResponse) {
  if (response.chatText) return response.chatText;
  const actions = response.actions.slice(0, 3).map((action) => `• ${action}`).join("\n");
  return `${response.summary}\n\n${actions}`;
}

const promptStarters: Record<SdgMode, string[]> = {
  learn: [
    "Explain SDG basics like I am new and then quiz me.",
    "Make a study plan for SDG 6 clean water and sanitation."
  ],
  mindcare: [
    "I feel stressed before my presentation. Guide me safely.",
    "I feel burned out from work. Help me reflect without diagnosing me."
  ],
  water: [
    "How can a country reduce water pollution and protect public health?",
    "There is brown smelly tap water in my area and people have stomach pain. What should we do?"
  ]
};

export default function HomePage() {
  const [mode, setMode] = useState<SdgMode>("learn");
  const [message, setMessage] = useState("");
  const [payload, setPayload] = useState<Record<string, string>>({});
  const [response, setResponse] = useState<AgentResponse | null>(null);
  const [chat, setChat] = useState<ChatItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const selectedMode = useMemo(() => modes.find((item) => item.mode === mode), [mode]);

  async function sendMessage() {
    const trimmed = message.trim();
    if (!trimmed && mode !== "water") {
      setError("Type a message first so Sage has something to respond to.");
      return;
    }

    setError("");
    setLoading(true);

    try {
      const userMessage = trimmed || "Please analyze this water report.";
      const res = await fetch("/api/sdg-agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode,
          message: userMessage,
          userId: "demo-user",
          payload: {
            ...payload,
            chatHistory: chat.slice(-6).flatMap((item) => [
              { role: "user", content: item.userMessage, mode: item.mode },
              { role: "assistant", content: item.response.chatText || item.response.summary, mode: item.mode }
            ])
          }
        })
      });

      const data = await res.json();

      if (!data.ok) {
        throw new Error(data.error || "Request failed.");
      }

      setResponse(data.data);
      setChat((previous) => [
        ...previous,
        {
          id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
          mode,
          userMessage,
          response: data.data
        }
      ]);
      setMessage("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen px-5 py-8 text-orange-50 md:px-8">
      <section className="mx-auto max-w-7xl">
        <nav className="mb-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="rounded-2xl bg-rose-500/25 p-3 text-rose-100 shadow-glow">
              <Sparkles size={28} />
            </div>
            <div>
              <p className="text-xl font-black tracking-tight text-white">Sage SDG AI</p>
              <p className="text-xs text-orange-100/70">Your human-like guide for learning, well-being, and clean water action.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="rounded-full border border-white/15 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10">
              Dashboard
            </Link>
            <a href="#agent" className="rounded-full bg-rose-500 px-4 py-2 text-sm font-bold text-white hover:bg-rose-400">
              Open Agent
            </a>
          </div>
        </nav>

        <div className="grid items-center gap-8 lg:grid-cols-[1.1fr_.9fr]">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-rose-300/25 bg-rose-500/10 px-4 py-2 text-sm text-rose-100">
              <ShieldCheck size={16} /> Data-driven safety-first SDG assistant
            </div>
            <h1 className="max-w-4xl text-4xl font-black leading-tight text-white md:text-6xl">
              Chat with an SDG agent trained around learning, mental well-being, and clean-water action.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-orange-50/80">
              Sage routes every request through <code className="rounded bg-black/40 px-2 py-1">/api/sdg-agent</code>, retrieves matching local SDG knowledge records, optionally uses Groq when an API key is added, and stores interactions in Supabase when credentials are connected.
            </p>
            <div className="mt-6 grid gap-3 text-sm text-orange-50/75 md:grid-cols-3">
              <div className="light-balance rounded-2xl p-4">Dataset-style knowledge for stress, burnout, reflection, and self-care.</div>
              <div className="light-balance rounded-2xl p-4">Water pollution, symptoms, reporting, and country-level response planning.</div>
              <div className="light-balance rounded-2xl p-4">Clear safety boundaries: no diagnosis, no prescriptions, no academic dishonesty.</div>
            </div>
          </div>

          <div className="safe-card rounded-[2rem] p-6 shadow-glow">
            <p className="text-sm uppercase tracking-[0.3em] text-rose-200">Presentation-ready</p>
            <h2 className="mt-3 text-2xl font-bold text-white">What this build now does</h2>
            <ul className="mt-5 space-y-3 text-sm leading-6 text-orange-50/80">
              <li>✓ Real chat history instead of only one static answer</li>
              <li>✓ Local SDG knowledge retrieval for mode-specific replies</li>
              <li>✓ Optional Groq AI responses when GROQ_API_KEY is added</li>
              <li>✓ AquaLife can discuss household reports and country-level water strategy</li>
              <li>✓ MindCare stays supportive without diagnosing or prescribing</li>
            </ul>
          </div>
        </div>

        <section id="agent" className="mt-14 grid gap-6 lg:grid-cols-[.78fr_1.22fr]">
          <div className="space-y-4">
            <h2 className="text-3xl font-black text-white">Choose a mode</h2>
            {modes.map((item) => (
              <ModeCard key={item.mode} {...item} active={mode === item.mode} onClick={setMode} />
            ))}
          </div>

          <div className="space-y-5">
            <div className="safe-card rounded-3xl p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-[0.25em] text-rose-200">Active mode</p>
                  <h2 className="text-2xl font-bold text-white">{selectedMode?.title}</h2>
                </div>
                <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-orange-100">POST /api/sdg-agent</span>
              </div>

              <WaterReportForm activeMode={mode} payload={payload} setPayload={setPayload} />

              <div className="mt-4 grid gap-2 md:grid-cols-2">
                {promptStarters[mode].map((starter) => (
                  <button
                    key={starter}
                    type="button"
                    onClick={() => setMessage(starter)}
                    className="rounded-2xl border border-white/10 bg-white/5 p-3 text-left text-xs leading-5 text-orange-50/75 transition hover:bg-white/10"
                  >
                    {starter}
                  </button>
                ))}
              </div>

              <textarea
                className="mt-4 min-h-36 w-full rounded-3xl border border-white/10 bg-black/35 p-4 text-white outline-none ring-rose-400/40 placeholder:text-orange-50/40 focus:ring-2"
                placeholder={placeholders[mode]}
                value={message}
                onChange={(event) => setMessage(event.target.value)}
              />

              {error ? <p className="mt-3 rounded-2xl bg-rose-500/15 p-3 text-sm text-rose-100">{error}</p> : null}

              <button
                type="button"
                onClick={sendMessage}
                disabled={loading}
                className="mt-4 inline-flex items-center gap-2 rounded-full bg-rose-500 px-6 py-3 font-bold text-white transition hover:bg-rose-400 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Send size={18} /> {loading ? "Thinking..." : "Send to Sage"}
              </button>
            </div>

            <div className="safe-card rounded-3xl p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <h3 className="text-xl font-bold text-white">Chat session</h3>
                <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-orange-100">{chat.length} exchanges</span>
              </div>

              {chat.length === 0 ? (
                <p className="text-sm leading-6 text-orange-50/75">
                  Ask something like: “How can a country reduce water pollution and protect public health?” or “Explain SDG basics like I am new.” Sage now answers in a real chat style using the built-in experience dataset and then shows structured evidence below.
                </p>
              ) : (
                <div className="max-h-[520px] space-y-5 overflow-y-auto pr-2">
                  {chat.map((item) => (
                    <div key={item.id} className="space-y-3">
                      <div className="ml-auto max-w-[88%] rounded-3xl bg-rose-500/25 p-4 text-sm leading-6 text-white">
                        <div className="mb-2 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-rose-100">
                          <UserRound size={14} /> You · {item.mode}
                        </div>
                        {item.userMessage}
                      </div>
                      <div className="max-w-[92%] rounded-3xl border border-white/10 bg-black/30 p-4 text-sm leading-6 text-orange-50/85">
                        <div className="mb-2 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-orange-100">
                          <Bot size={14} /> Sage SDG AI
                        </div>
                        <p className="whitespace-pre-line">{formatAssistantBubble(item.response)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <AgentResponseCard response={response} loading={loading} />
          </div>
        </section>
      </section>
    </main>
  );
}

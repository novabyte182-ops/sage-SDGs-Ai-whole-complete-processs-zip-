# Replit Steps

1. Upload/extract this ZIP into a Replit Node.js project.
2. Make sure these files are visible at the root:
   - `package.json`
   - `.replit`
   - `app/`
   - `components/`
   - `lib/`
   - `data/`
3. Click **Run**.
4. For Replit deployment, use:

Build command:
```bash
npm install && npm run build
```

Run command:
```bash
npm run start -- -H 0.0.0.0 -p 3000
```

Port:
```text
3000
```

## Optional secrets

Add these in Replit Secrets only if you have them:

```text
GROQ_API_KEY=your_key
GROQ_MODEL=llama-3.1-8b-instant
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

The app still runs without these keys.

import dataset from "@/data/sdg_experience_dataset.json";
import manifest from "@/data/kaggle_dataset_manifest.json";
import type { SdgMode } from "@/lib/types";

export type ExperienceRecord = {
  id: string;
  mode: SdgMode;
  sdg: string;
  domain: string;
  topic: string;
  keywords: string[];
  scenario: string;
  evidence: string;
  indicators: string[];
  agent_guidance: string;
  actions: string[];
  escalation: string;
  source_name: string;
  source_type: string;
};

export type DatasetManifestItem = {
  domain: string;
  name: string;
  example_slug: string;
  use_in_app: string;
};

const records = dataset as ExperienceRecord[];
const datasetManifest = manifest as DatasetManifestItem[];

function tokenize(text: string) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2);
}

function scoreRecord(record: ExperienceRecord, query: string) {
  const lower = query.toLowerCase();
  const tokens = new Set(tokenize(lower));
  let score = 0;

  for (const keyword of record.keywords) {
    const normalized = keyword.toLowerCase();
    if (lower.includes(normalized)) score += normalized.includes(" ") ? 12 : 8;
    if (tokens.has(normalized)) score += 5;
  }

  for (const token of tokens) {
    if (record.topic.toLowerCase().includes(token)) score += 4;
    if (record.domain.toLowerCase().includes(token)) score += 3;
    if (record.scenario.toLowerCase().includes(token)) score += 2;
    if (record.evidence.toLowerCase().includes(token)) score += 1;
    if (record.agent_guidance.toLowerCase().includes(token)) score += 1;
  }

  return score;
}

export function retrieveExperienceRecords(mode: SdgMode, message: string, payload: Record<string, unknown> = {}, limit = 5) {
  const payloadText = Object.values(payload)
    .map((value) => (typeof value === "string" ? value : JSON.stringify(value)))
    .join(" ");
  const query = `${message} ${payloadText}`;

  const scored = records
    .filter((record) => record.mode === mode)
    .map((record) => ({ record, score: scoreRecord(record, query) }))
    .sort((a, b) => b.score - a.score);

  const positive = scored.filter((item) => item.score > 0).slice(0, limit).map((item) => item.record);

  if (positive.length) return positive;
  return records.filter((record) => record.mode === mode).slice(0, limit);
}

export function getDatasetManifest() {
  return datasetManifest;
}

export function getModeDatasetSummary(mode: SdgMode) {
  const modeRecords = records.filter((record) => record.mode === mode);
  const domains = Array.from(new Set(modeRecords.map((record) => record.domain)));
  return {
    totalRecords: modeRecords.length,
    domains,
    sources: Array.from(new Set(modeRecords.map((record) => record.source_name)))
  };
}

export function getDatasetMatchesForResponse(recordsForResponse: ExperienceRecord[]) {
  return recordsForResponse.map((record) => ({
    id: record.id,
    topic: record.topic,
    sdg: record.sdg,
    domain: record.domain,
    source: record.source_name,
    indicators: record.indicators.slice(0, 3)
  }));
}

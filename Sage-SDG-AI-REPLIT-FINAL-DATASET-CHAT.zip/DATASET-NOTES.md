# Sage SDG AI Dataset Notes

This build includes a local experience-style SDG dataset so the agent can chat properly even without external APIs.

## Built-in files

- `data/sdg_experience_dataset.json` — curated experience records for Learn, MindCare, and AquaLife.
- `data/kaggle_dataset_manifest.json` — Kaggle-ready dataset source manifest.
- `data/water_quality_seed_sample.csv` — water-risk seed cases.
- `data/mental_wellbeing_seed_sample.csv` — mental well-being seed cases.
- `data/learning_progress_seed_sample.csv` — learning/progress seed cases.

## Important honesty note

Kaggle datasets usually require Kaggle login/API credentials and each dataset has its own license. This ZIP does not illegally redistribute large Kaggle downloads. Instead, it ships with a working local experience dataset and a manifest showing which Kaggle datasets can be connected later.

## How Sage uses data

1. The user selects a mode.
2. `/api/sdg-agent` retrieves matching records from `sdg_experience_dataset.json`.
3. The agent generates a conversational answer plus structured actions, follow-up questions, and dataset matches.
4. If `GROQ_API_KEY` is added, Groq rewrites the answer more naturally while still using the local dataset context.
5. If Supabase keys are added, every interaction is saved for dashboard analytics.

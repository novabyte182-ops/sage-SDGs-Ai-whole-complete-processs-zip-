-- Sage SDG AI Supabase Schema
-- Paste this file into Supabase SQL Editor and run once.
-- Then add environment variables in Vercel.

create extension if not exists pgcrypto;

create table if not exists public.interactions (
  id uuid primary key default gen_random_uuid(),
  user_id text not null default 'demo-user',
  mode text not null check (mode in ('learn', 'mindcare', 'water')),
  message text not null,
  response_title text,
  response_summary text,
  safety_level text not null default 'low',
  payload jsonb not null default '{}'::jsonb,
  response_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.learn_progress (
  id uuid primary key default gen_random_uuid(),
  user_id text not null default 'demo-user',
  topic text not null,
  progress_delta integer not null default 5,
  skill text,
  created_at timestamptz not null default now()
);

create table if not exists public.mindcare_reflections (
  id uuid primary key default gen_random_uuid(),
  user_id text not null default 'demo-user',
  reflection text not null,
  safety_level text not null default 'medium',
  created_at timestamptz not null default now()
);

create table if not exists public.water_reports (
  id uuid primary key default gen_random_uuid(),
  user_id text not null default 'demo-user',
  location text not null default 'Unknown',
  category text not null default 'water quality concern',
  symptoms text,
  people_affected text,
  urgency text not null default 'low',
  raw_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.interactions enable row level security;
alter table public.learn_progress enable row level security;
alter table public.mindcare_reflections enable row level security;
alter table public.water_reports enable row level security;

-- The Next.js API route should use SUPABASE_SERVICE_ROLE_KEY on the server.
-- Service role bypasses RLS, so no public write policy is needed.
-- For demo-only public read/write from browser, add policies carefully, but this project avoids exposing database writes in the client.

create index if not exists interactions_mode_created_at_idx on public.interactions (mode, created_at desc);
create index if not exists water_reports_urgency_created_at_idx on public.water_reports (urgency, created_at desc);
create index if not exists learn_progress_user_created_at_idx on public.learn_progress (user_id, created_at desc);

import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        sage: {
          black: "#07070a",
          panel: "#111116",
          red: "#e11d48",
          redDark: "#991b1b",
          gold: "#f59e0b",
          mint: "#14b8a6",
          blue: "#38bdf8",
          cream: "#fff7ed"
        }
      },
      boxShadow: {
        glow: "0 0 45px rgba(225, 29, 72, 0.18)"
      }
    }
  },
  plugins: []
};

export default config;

"""Kaggle ingestion placeholder for Sage SDGs AI.
This script is prepared for the next phase. It does not include private Kaggle keys.
Set KAGGLE_USERNAME and KAGGLE_KEY in your environment, then add exact Kaggle dataset slugs.
"""
import os, json
from pathlib import Path

DATASET_SLUGS = {
    "World Bank Sustainable Development Goals Dataset": "theworldbank/sustainable-development-goals",
    "World Bank Education Statistics / EdStats": "theworldbank/education-statistics",
    "World Bank Education Data": "theworldbank/world-bank-intl-education",
    "Climate Watch": "adams3/climatewatch",
    "International Greenhouse Gas Emissions": "unitednations/international-greenhouse-gas-emissions",
}

def main():
    if not (os.getenv('KAGGLE_USERNAME') and os.getenv('KAGGLE_KEY')):
        raise SystemExit('Set KAGGLE_USERNAME and KAGGLE_KEY before running ingestion.')
    print('Kaggle credentials found. Install kaggle package and download selected dataset slugs as needed.')
    print(json.dumps(DATASET_SLUGS, indent=2))

if __name__ == '__main__':
    main()

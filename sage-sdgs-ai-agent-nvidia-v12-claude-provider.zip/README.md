# Sage SDGs AI — Global Intelligence Mega Multi-Agent v8

This package contains the verified **Sage SDGs AI v8 Global Intelligence Mega Multi-Agent** prototype. It is designed as an AI agent, not a simple chatbot.

## Core features included through v8

- Agent command mode: `/report`, `/campaign`, `/compare`, `/vision`, `/dataset`, `/remember`, and “Sage, …” style commands.
- Real RAG-ready layer: local `data/rag_seed.json`, dataset routing, evidence retrieval, and future Kaggle ingestion script.
- Memory database: SQLite memory and conversation tables created automatically in `data/sage_memory.db` at runtime.
- Voice assistant mode: text-to-speech, microphone input, emotion presets, voice selector, and uploaded voice sample preview.
- Client credential layer: demo User/Admin/Client login, tokens, and role-aware dashboard previews.
- Live model providers: DeepSeek V4 Flash, Mistral Medium 3.5, and Kimi K2.6 through server-side `NVIDIA_API_KEY`, plus Claude Opus 4.7 Fast through server-side `OPENROUTER_API_KEY`.
- Dataset engine with all discussed SDG 3, SDG 4, and SDG 13 datasets.
- Vision 2030 and Vision 2035 alignment section.

## Run locally

```bash
cd sage-sdgs-ai-agent-nvidia
python -m venv .venv
source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
uvicorn backend.server:app --host 0.0.0.0 --port 8000 --reload
```

In another terminal:

```bash
python -m http.server 8080 --directory frontend
```

Open `http://localhost:8080`.

## Environment variables

No real keys are included. Add them only in backend hosting settings:

```bash
NVIDIA_API_KEY=your_nvidia_key
OPENROUTER_API_KEY=your_openrouter_key
KAGGLE_USERNAME=your_kaggle_username
KAGGLE_KEY=your_kaggle_key
```

## Demo credentials

- User: `user@sage.local` / `user123`
- Admin: `admin@sage.local` / `admin123`
- Client: `client@sage.local` / `client123`

These are prototype credentials only. Replace with production authentication before final deployment.

## Important note about voice

The uploaded voice sample is included as a preview file. The website can speak using browser voices and emotional presets now. Exact cloned voice generation needs a licensed TTS/voice-cloning backend provider and user consent.


## Ultimate Jarvis-Style Additions

The package includes the requested advanced agent features: agent command mode extensions, real Kaggle RAG readiness, memory DB, conversational voice assistant controls, client credential/workspace layer, report export, SDG impact score engine, project generator, presentation mode, emergency safety mode, admin AI control panel, and cross-SDG knowledge graph.

Use the existing FastAPI backend for live NVIDIA responses. Run:

```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000 --reload
```

Then open `http://localhost:8000` or serve the frontend separately with `python -m http.server 8080 --directory frontend`.


## Icon Update
- Added the provided Sage SDGs AI icon/logo file at `assets/sage-sdgs-ai-icon.png`.
- Linked it as the browser favicon and Apple touch icon.
- Replaced the text-only topbar icon with the provided visual brand icon.
- The image is included locally in the ZIP, so deployment does not depend on external image hosting.

## Lovable Deployment Note
This package is deployment-ready as a prototype. If importing into Lovable, use the frontend design and backend logic as the specification/base. Keep `NVIDIA_API_KEY`, `KAGGLE_USERNAME`, and `KAGGLE_KEY` as server-side environment variables only.


## Final self-introduction upgrade

The agent now introduces itself clearly in the hero area, the agent console, and backend demo responses. It explains who Sage SDGs AI is, what it is designed for, and how it supports SDG 3, SDG 4, SDG 13, RAG, memory, reports, campaigns, projects, and Vision 2030/2035 alignment.


## v8 Global Intelligence Additions

The v8 ZIP also includes multilingual support, a project lifecycle tracker, predictive analytics simulator, and collaboration workspace features. These are available in the **Global Intelligence Upgrades** section of the website and preserve all previous Sage SDGs AI agent, RAG, memory, voice, dataset, dashboard, and presentation features.


## Chat Fix Update

The Agent Console now includes a robust client-side fallback engine. If the backend is unavailable on a static host, Sage SDGs AI still responds conversationally in demo mode. Live NVIDIA/API responses are used automatically when the backend is running and configured.


## NVIDIA Provider Update

This version includes backend support for `moonshotai/kimi-k2.6` using the direct NVIDIA chat completions endpoint. Add `NVIDIA_API_KEY` only in the server environment.


## v12 Claude/OpenRouter Provider Update

This package adds a fourth live model provider option: `anthropic/claude-opus-4.7-fast` through OpenRouter. For safety, no real API keys are included in the ZIP. Add your key only as a server-side environment variable named `OPENROUTER_API_KEY`.

Important: if you pasted real API keys in chat or any public place, revoke/rotate them in your provider dashboard before production use.

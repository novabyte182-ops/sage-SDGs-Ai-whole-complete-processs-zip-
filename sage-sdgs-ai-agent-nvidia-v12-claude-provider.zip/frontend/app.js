const API_BASE = window.SAGE_API_BASE || ((window.location.protocol === 'file:' || window.location.port === '8080') ? 'http://localhost:8000' : window.location.origin);
let history = [];
let taskMode = 'conversation';
let currentUser = null;
let datasets = [];
let availableVoices = [];
let lastAiReply = 'Hello, I’m Sage SDGs AI — your intelligent multi-agent assistant for Sustainable Development Goals 3, 4, and 13. I am designed to support health and well-being, quality education, and climate action through dataset-backed insights, RAG-style retrieval, memory, SDG impact analysis, project generation, report support, and Vision 2030/2035 alignment. You can ask me to compare countries, generate reports, design awareness campaigns, create SDG projects, explain dataset evidence, or prepare presentation-ready recommendations.';

const $ = id => document.getElementById(id);
const escapeHtml = s => (s || '').replace(/[&<>\"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function addMsg(role, text){ const wrap=document.createElement('div'); wrap.className=`msg ${role}`; wrap.innerHTML=`<b>${role==='ai'?'Sage SDGs AI':'You'}</b><p>${escapeHtml(text)}</p>`; $('messages').appendChild(wrap); $('messages').scrollTop=1e9; return wrap.querySelector('p'); }
function detectCommand(text){ const t=text.trim().toLowerCase(); if(t.startsWith('/report')) return 'report'; if(t.startsWith('/campaign')) return 'campaign'; if(t.startsWith('/compare')) return 'compare'; if(t.startsWith('/vision')) return 'vision'; if(t.startsWith('/remember')) return 'remember'; if(t.startsWith('/dataset')) return 'dataset'; if(t.startsWith('/solve') || t.startsWith('/experience')) return 'experience'; if(t.startsWith('/project')) return 'project'; if(t.startsWith('/score')) return 'score'; if(t.startsWith('/presentation')) return 'presentation'; if(t.startsWith('/graph')) return 'graph'; if(t.startsWith('/emergency')) return 'emergency'; if(t.startsWith('sage,')) return 'command'; return taskMode; }
function routeDataset(text, sdg){ const low=text.toLowerCase(); if(sdg==='SDG 4'||/education|school|literacy|teacher|learning|student/.test(low))return 'World Bank Education Statistics / EdStats'; if(sdg==='SDG 13'||/climate|co2|emission|carbon|heat|flood|greenhouse/.test(low))return 'Climate Watch + CO₂/GHG'; if(sdg==='SDG 3'||/health|disease|wellbeing|mortality|mental|maternal|vaccine/.test(low))return 'World Health Statistics Report by WHO'; return 'World Bank SDGs + WDI'; }
async function loadDatasets(){ try{ const r=await fetch('../data/datasets.json'); datasets=await r.json(); const grid=$('datasetGrid'); const select=$('datasetSelect'); grid.innerHTML=''; select.innerHTML='<option value="auto">Auto dataset routing</option>'; datasets.forEach(d=>{ const card=document.createElement('article'); card.className='datasetCard'; card.innerHTML=`<h3>${escapeHtml(d.name)}</h3><div>${(d.sdgs||[]).map(s=>`<span class="tag">${s}</span>`).join('')}<span class="tag ${d.type==='Core'?'core':''}">${d.type}</span></div><p>${escapeHtml(d.use)}</p>`; grid.appendChild(card); const opt=document.createElement('option'); opt.value=d.name; opt.textContent=d.name; select.appendChild(opt); }); }catch(e){ console.warn(e); } }
loadDatasets();

async function checkApi(){ try{ const r=await fetch(`${API_BASE}/api/health`); const j=await r.json(); $('apiStatus').textContent = j.nvidia_key_configured ? 'API: Live' : 'API: Demo'; }catch(e){ $('apiStatus').textContent='API: Frontend demo'; } }
checkApi();

function renderDashboard(view){ const el=$('dashboardView'); const role=currentUser?.role || 'guest'; const locked = (view==='admin' && role!=='admin') || (view==='client' && !['client','admin'].includes(role)); if(locked){ el.innerHTML=`<h3>${view.toUpperCase()} view locked</h3><p class="sectionLead">Sign in with the correct demo credential to preview this confidential dashboard layer.</p>`; return; }
 const copy={user:'Ask questions, use voice, generate SDG reports, compare countries, and save project memory.', admin:'Monitor APIs, datasets, RAG status, safety logs, users, and Kaggle refresh schedules.', client:'Manage organization projects, private reports, Vision 2030/2035 scores, and export-ready deliverables.'}[view];
 el.innerHTML=`<h3>${view[0].toUpperCase()+view.slice(1)} Dashboard</h3><p class="sectionLead">${copy}</p><div class="kpiGrid"><div class="kpi"><b>3</b><span>Core SDGs</span></div><div class="kpi"><b>14</b><span>Dataset Layers</span></div><div class="kpi"><b>8</b><span>Agent Modules</span></div><div class="kpi"><b>2</b><span>Vision Frameworks</span></div></div>`; }
document.querySelectorAll('.viewBtn').forEach(b=>b.addEventListener('click',()=>renderDashboard(b.dataset.view)));
renderDashboard('user');

$('loginBtn').addEventListener('click', async()=>{ try{ const r=await fetch(`${API_BASE}/api/login`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email:$('emailInput').value, password:$('passwordInput').value, role:$('roleSelect').value})}); const j=await r.json(); if(!r.ok) throw new Error(j.detail || 'Login failed'); currentUser=j.user; localStorage.setItem('sage_token', j.token); $('loginStatus').textContent=`Signed in as ${j.user.role}: ${j.user.email}`; $('insightRole').textContent=j.user.role; $('insightMemory').textContent='Memory DB active'; }catch(err){ $('loginStatus').textContent=err.message; }});

document.querySelectorAll('.mode').forEach(btn=>btn.addEventListener('click',()=>{ document.querySelectorAll('.mode').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); taskMode=btn.dataset.mode; $('insightCommand').textContent=taskMode; }));
document.querySelectorAll('.quickPrompts button').forEach(btn=>btn.addEventListener('click',()=>{ $('chatInput').value=btn.textContent; $('chatForm').requestSubmit(); }));

function loadVoices(){ const select=$('voiceSelect'); if(!select || !('speechSynthesis' in window)) return; availableVoices=window.speechSynthesis.getVoices(); const preferred=availableVoices.filter(v=>/en-|English/i.test(v.lang+' '+v.name)).sort((a,b)=>{ const score=v=>/natural|premium|enhanced|neural|google|microsoft|zira|samantha|aria|jenny/i.test(v.name)?0:1; return score(a)-score(b) || a.name.localeCompare(b.name); }); const voices=preferred.length?preferred:availableVoices; select.innerHTML=voices.map(v=>`<option value="${availableVoices.indexOf(v)}">${v.name} — ${v.lang}</option>`).join('') || '<option>No browser voices found</option>'; }
function emotionSettings(){ const e=$('emotionSelect')?.value || 'professional'; const map={professional:[0.95,1.0],warm:[0.92,1.05],confident:[0.98,0.95],empathetic:[0.86,0.98],energetic:[1.08,1.08]}; return map[e] || map.professional; }
function cleanForSpeech(text){ return (text||'').replace(/[#*_`>]/g,'').replace(/https?:\/\/\S+/g,'link').replace(/\s+/g,' ').trim(); }
function speak(text){ if(!text || !('speechSynthesis' in window)) return; window.speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(cleanForSpeech(text)); const selected=availableVoices[Number($('voiceSelect')?.value)]; if(selected) u.voice=selected; const [er,ep]=emotionSettings(); u.rate=Number($('voiceRate')?.value || er); u.pitch=Number($('voicePitch')?.value || ep); u.volume=1; u.onstart=()=>{document.body.classList.add('speaking'); $('insightVoice').textContent='Speaking';}; u.onend=()=>{document.body.classList.remove('speaking'); $('insightVoice').textContent='TTS ready';}; u.onerror=()=>document.body.classList.remove('speaking'); window.speechSynthesis.speak(u); }
function maybeSpeak(text){ lastAiReply=text||lastAiReply; if($('voiceAuto')?.checked) speak(lastAiReply); }
if('speechSynthesis' in window){ loadVoices(); window.speechSynthesis.onvoiceschanged=loadVoices; }
$('speakLast').addEventListener('click',()=>speak(lastAiReply));
$('stopVoice').addEventListener('click',()=>{ if('speechSynthesis' in window) window.speechSynthesis.cancel(); document.body.classList.remove('speaking'); });
$('previewMyVoice').addEventListener('click',()=>{ const a=$('userVoiceAudio'); if(a){ a.currentTime=0; a.play(); $('insightVoice').textContent='Playing uploaded sample'; }});
$('emotionSelect').addEventListener('change',()=>{ const [r,p]=emotionSettings(); $('voiceRate').value=r; $('voicePitch').value=p; });

let recognition=null; function setupRecognition(){ const SR=window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR) return null; const rec=new SR(); rec.lang='en-US'; rec.interimResults=false; rec.continuous=false; rec.onstart=()=>{$('insightVoice').textContent='Listening';}; rec.onresult=e=>{ const transcript=e.results[0][0].transcript; $('chatInput').value=transcript; $('chatForm').requestSubmit();}; rec.onerror=()=>{$('insightVoice').textContent='Voice input unavailable';}; rec.onend=()=>{ if($('insightVoice').textContent==='Listening') $('insightVoice').textContent='TTS ready';}; return rec; }
$('startListening').addEventListener('click',()=>{ recognition=recognition||setupRecognition(); if(recognition) recognition.start(); else alert('Speech recognition is not supported in this browser. Use Chrome/Edge for voice input.'); });




// Experience-based problem solving engine for Sage SDGs AI.
// It turns the agent from a simple responder into a decision-support partner:
// understand problem -> classify SDG roots -> retrieve relevant experience pattern -> produce action plan.
const experiencePlaybooks = [
  {
    name: 'Climate-health school disruption',
    triggers: /flood|heat|climate|school|absence|children|disease|water|sanitation/i,
    sdgs: ['SDG 13', 'SDG 3', 'SDG 4'],
    lesson: 'Climate shocks often become health and education problems at the same time. Protect water, protect attendance, and communicate early.',
    actions: ['Map affected learners and health risks', 'Create safe-water and hygiene messaging', 'Prepare school continuity plan', 'Coordinate local health and education stakeholders']
  },
  {
    name: 'Low awareness / weak community participation',
    triggers: /awareness|campaign|community|participation|students|parents|training|workshop/i,
    sdgs: ['SDG 3', 'SDG 4'],
    lesson: 'Awareness improves when messages are local, repeated, visual, and connected to daily problems.',
    actions: ['Define one clear behavior change', 'Use school/university ambassadors', 'Run pre/post awareness check', 'Create simple posters and WhatsApp-ready messages']
  },
  {
    name: 'Data-to-policy gap',
    triggers: /policy|report|dashboard|indicator|dataset|evidence|government|ngo|client/i,
    sdgs: ['Cross-SDG'],
    lesson: 'Decision-makers need short evidence, clear indicators, and realistic implementation steps, not long generic text.',
    actions: ['Select 3-5 measurable indicators', 'Compare baseline and target country/region', 'Write a one-page policy brief', 'Add risk, cost, and monitoring indicators']
  },
  {
    name: 'Health misinformation / unsafe advice risk',
    triggers: /cure|medicine|vaccine|fake|myth|prescribe|treatment|mental|emergency/i,
    sdgs: ['SDG 3'],
    lesson: 'Health guidance must remain educational, safe, and professional. High-risk symptoms require qualified help.',
    actions: ['Detect risk level', 'Correct misinformation gently', 'Avoid diagnosis or prescriptions', 'Recommend professional/emergency support where needed']
  }
];
function experienceSolve(text, sdg, country, ds){
  const q=(text||'').trim();
  const matched = experiencePlaybooks.find(p=>p.triggers.test(q)) || experiencePlaybooks[2];
  const place = country || 'the selected community/region';
  const rootCauses = [];
  if(/climate|flood|heat|co2|emission|pollution/i.test(q)) rootCauses.push('environmental/climate pressure');
  if(/health|disease|dengue|mental|nutrition|medicine|hygiene/i.test(q)) rootCauses.push('health vulnerability');
  if(/education|school|student|teacher|literacy|learning/i.test(q)) rootCauses.push('education access or learning continuity');
  if(/data|policy|report|dashboard|indicator|evidence/i.test(q)) rootCauses.push('data-to-action gap');
  if(!rootCauses.length) rootCauses.push('unclear problem framing that needs SDG scoping');
  const actions = matched.actions.map((a,i)=>`${i+1}. ${a}`).join('\n');
  return `Experience-Based Problem Solver activated.\n\nProblem understood: ${q || 'No detailed problem was provided yet.'}\nRegion/client context: ${place}\nMatched experience pattern: ${matched.name}\nRelevant SDGs: ${matched.sdgs.join(' + ')}\nDataset route: ${ds}\n\nWhat experience suggests:\n${matched.lesson}\n\nLikely root causes:\n- ${rootCauses.join('\n- ')}\n\nRecommended action plan:\n${actions}\n\n90-second agent decision:\nStart with a small, measurable intervention, connect it to one SDG 3/4/13 indicator, produce a simple dashboard/report, and review impact after the first milestone.\n\nNext commands: /project to build the plan, /score to estimate impact, /campaign to create awareness material, or /report to make it presentation-ready.`;
}

// Robust client-side Sage SDGs AI demo brain.
// This keeps the Agent Console fully conversational even when a static host
// does not run the FastAPI backend. When the backend is available, live API
// responses are still used first.
function localAgentReply({text, sdg, country, ds, command}){
  const q=(text||'').trim();
  const low=q.toLowerCase();
  const place=country || (low.includes('pakistan')?'Pakistan': low.includes('bangladesh')?'Bangladesh':'your selected country/region');
  const selected = sdg==='auto' ? (low.match(/climate|co2|emission|flood|heat/) ? 'SDG 13' : low.match(/education|school|student|teacher|literacy/) ? 'SDG 4' : low.match(/health|disease|dengue|mental|wellbeing|maternal/) ? 'SDG 3' : 'Cross-SDG') : sdg;
  if(/who are you|introduce|what are you|\/intro/.test(low)){
    return `Hello, I’m Sage SDGs AI — your intelligent multi-agent assistant for SDG 3, SDG 4, and SDG 13. I am designed for health and well-being, quality education, and climate action. I can compare countries, generate SDG reports, design campaigns, build project plans, explain dataset evidence, support Vision 2030/2035 alignment, and prepare presentation-ready recommendations. I’m currently answering in website demo mode, so the interface remains fully functional even before live API keys are connected.`;
  }
  if(command==='report' || low.includes('report')){
    return `I can prepare that report. Here is a presentation-ready SDG report outline for ${place} focused on ${selected}.\n\n1. Executive focus: link SDG 3 health outcomes, SDG 4 education access, and SDG 13 climate resilience.\n2. Dataset evidence layer: ${ds}.\n3. Key analysis: identify risk patterns, compare indicators, and highlight vulnerable groups.\n4. Recommendations: strengthen public-health awareness, school-based SDG education, climate adaptation, and data-driven monitoring.\n5. Vision alignment: connect actions with Vision 2030 short-to-medium-term targets and Vision 2035 long-term sustainable development priorities.\n\nNext action: click Export Report to download a report draft, or ask me to expand any section.`;
  }
  if(command==='compare' || low.includes('compare')){
    return `Comparison mode is ready. For ${place}, I would compare SDG indicators using ${ds}.\n\nDemo comparison logic:\n• SDG 3: life expectancy, mortality, disease prevention, health access.\n• SDG 4: literacy, enrolment, completion, learning access.\n• SDG 13: emissions, climate risk, adaptation readiness.\n\nInsight: the strongest cross-SDG comparison is not one number; it is the relationship between climate pressure, health vulnerability, and education continuity. Tell me the two countries and I will format it as a table.`;
  }
  if(command==='campaign' || low.includes('campaign')){
    return `Campaign builder activated.\n\nCampaign title: Healthy Minds, Educated Futures, Climate-Safe Communities\nTarget: ${place}\nSDG focus: ${selected}\nCore message: Better health, stronger learning, and climate resilience must grow together.\nActivities:\n1. School or university awareness session.\n2. Social media poster series.\n3. Community health and climate safety checklist.\n4. Student pledge and feedback survey.\nEvaluation: attendance, awareness quiz improvement, campaign reach, and SDG impact score.`;
  }
  if(command==='experience' || low.includes('solve') || low.includes('problem') || low.includes('experience')){
    return experienceSolve(q, selected, country, ds);
  }
  if(command==='project' || low.includes('project') || low.includes('build')){
    return generateBlueprint();
  }
  if(command==='vision' || low.includes('vision 2030') || low.includes('vision 2035')){
    return `Vision Alignment Engine result:\n\nYour idea aligns with Vision 2030 by supporting near-term measurable progress in public health, education quality, youth awareness, and climate resilience. It aligns with Vision 2035 by promoting long-term sustainable communities, data-driven governance, resilient institutions, and inclusive development.\n\nSDG mapping:\n• SDG 3: improved health awareness and prevention.\n• SDG 4: stronger learning and SDG literacy.\n• SDG 13: climate action, adaptation, and risk awareness.`;
  }
  if(command==='dataset' || low.includes('dataset') || low.includes('evidence')){
    return `Dataset Evidence Mode:\n\nFor this query, I would route evidence through: ${ds}.\nCore dataset stack includes World Bank SDGs, World Development Indicators, WHO health statistics, World Bank Education/EdStats, Climate Watch, CO₂ and greenhouse gas emissions, UNICEF child indicators, and lifestyle/wellbeing data.\n\nRAG flow: query → SDG selector → dataset selector → evidence retrieval → multi-agent reasoning → safety review → final answer.`;
  }
  if(command==='remember' || low.includes('remember')){
    return `Memory updated in demo mode. I will treat this as project context for this session: “${q}”.\n\nSelector memory now keeps track of your SDG focus, preferred country/region, dataset route, task mode, and client-style output preference.`;
  }
  if(command==='score' || low.includes('score') || low.includes('impact')){
    const sc=scoreProject(q);
    return `SDG Impact Score estimate:\n• SDG 3 health impact: ${sc.sdg3}%\n• SDG 4 education impact: ${sc.sdg4}%\n• SDG 13 climate impact: ${sc.sdg13}%\n• Feasibility: ${sc.feasibility}%\n• Vision 2030/2035 readiness: ${sc.vision}%\n\nThis is a prototype score. A production score should be calculated from real Kaggle-hosted indicators and client project data.`;
  }
  if(command==='presentation' || low.includes('presentation')){
    return `Presentation Mode ready. I can introduce the project like this:\n\nHello, I am Sage SDGs AI, a mega multi-agent platform for SDG 3, SDG 4, and SDG 13. I combine dataset-backed evidence, RAG-style retrieval, memory, voice interaction, dashboards, predictive analytics, project tracking, and Vision 2030/2035 alignment to support students, researchers, clients, NGOs, and policy-focused users.`;
  }
  const safety=safetyPrecheck(q);
  if(safety) return safety;
  return `I understand. Let’s work on this as Sage SDGs AI.\n\nDetected focus: ${selected}\nDataset route: ${ds}\nRegion: ${place}\n\nHere is my agent-style response: your topic should be analyzed through the connection between health outcomes, education quality, and climate resilience. I can turn this into a report, campaign, project blueprint, country comparison, dataset explanation, or Vision 2030/2035 alignment.\n\nRecommended next command: /report, /campaign, /compare, /project, /dataset, or /vision.`;
}

$('chatForm').addEventListener('submit', async(e)=>{ e.preventDefault(); const input=$('chatInput'); const text=input.value.trim(); if(!text) return; input.value=''; addMsg('user', text); history.push({role:'user', content:text}); const sdg=$('sdgSelect').value; const country=$('countryInput').value; const ds=$('datasetSelect').value==='auto'?routeDataset(text,sdg):$('datasetSelect').value; const command=detectCommand(text); $('insightSdg').textContent=sdg; $('insightDataset').textContent=ds; $('insightCommand').textContent=command; $('insightRag').textContent='Retrieving'; const aiP=addMsg('ai','Thinking as Sage SDGs AI mega agent...'); try{ const token=localStorage.getItem('sage_token') || ''; const controller=new AbortController(); const timeout=setTimeout(()=>controller.abort(), 6500); const r=await fetch(`${API_BASE}/api/agent`,{method:'POST',headers:{'Content-Type':'application/json','Authorization': token?`Bearer ${token}`:''},body:JSON.stringify({messages:history,selected_sdg:sdg,selected_country:country,selected_dataset:ds,task_mode:command,stream:false,provider:$('providerSelect')?.value||'deepseek', client_id: currentUser?.client_id || 'demo-client'}), signal:controller.signal}); clearTimeout(timeout); if(!r.ok) throw new Error('Backend returned '+r.status); const j=await r.json(); aiP.textContent=j.response || localAgentReply({text,sdg,country,ds,command}); history.push({role:'assistant', content:aiP.textContent}); maybeSpeak(aiP.textContent); $('insightDataset').textContent=j.selected_dataset||ds; $('insightRag').textContent=j.mode==='live'?'Live model provider + RAG context':'Demo RAG + local seed'; $('insightMemory').textContent=j.memory_status || 'Short-term + selector'; if($('voiceListenAuto')?.checked) setTimeout(()=>$('startListening').click(), 1200); }catch(err){ aiP.textContent=localAgentReply({text,sdg,country,ds,command}); history.push({role:'assistant', content:aiP.textContent}); $('insightRag').textContent='Website demo mode'; $('insightMemory').textContent='Local session memory'; $('insightDataset').textContent=ds; maybeSpeak(aiP.textContent); if($('voiceListenAuto')?.checked) setTimeout(()=>$('startListening').click(), 1200); } });


// v6 Ultimate Jarvis-style additions
const emergencyTerms = /(chest pain|can't breathe|cannot breathe|suicide|self harm|overdose|unconscious|severe bleeding|stroke|heart attack|emergency|dangerous medicine|prescribe)/i;
function safetyPrecheck(text){
  if(!emergencyTerms.test(text)) return null;
  return "Safety alert: I can provide public-health education, but this may be urgent. If there is immediate danger, severe symptoms, self-harm risk, breathing difficulty, chest pain, overdose, unconsciousness, or severe bleeding, contact local emergency services or a qualified medical professional immediately. I will avoid diagnosis or prescribing and keep guidance safe.";
}

function scoreProject(text){
  const low=(text||'').toLowerCase();
  let sdg3=35, sdg4=35, sdg13=35;
  if(/health|dengue|mental|disease|wellbeing|maternal|nutrition|hygiene/.test(low)) sdg3+=45;
  if(/education|school|student|teacher|literacy|training|awareness|university/.test(low)) sdg4+=42;
  if(/climate|co2|carbon|flood|heat|resilience|environment|emission/.test(low)) sdg13+=42;
  const feasibility = Math.min(95, 55 + (low.length>30?18:8) + (/community|campaign|training|school|local/.test(low)?12:0));
  const vision = Math.round((sdg3+sdg4+sdg13+feasibility)/4);
  return {sdg3:Math.min(98,sdg3), sdg4:Math.min(98,sdg4), sdg13:Math.min(98,sdg13), feasibility, vision};
}
function renderScore(target, scores){
  target.innerHTML = Object.entries(scores).map(([k,v])=>`<div><b>${k.toUpperCase().replace('SDG','SDG ')}</b> — ${v}%<div class="scoreBar"><span style="width:${v}%"></span></div></div>`).join('') + '<p class="sectionLead">Interpretation: this is a prototype scoring model. Production scoring should use real indicators from Kaggle-hosted datasets and client-specific criteria.</p>';
}
function generateBlueprint(){
  const country=$('projectCountry')?.value||'Pakistan'; const community=$('projectCommunity')?.value||'community'; const sdg=$('projectSdg')?.value||'Cross-SDG'; const duration=$('projectDuration')?.value||'8 weeks';
  return `Sage SDGs AI Project Blueprint\n\nTitle: Integrated ${sdg} Action Program for ${community} in ${country}\n\nGoal: Improve health, education, and climate resilience through a data-backed community intervention.\n\nDuration: ${duration}\n\nObjectives:\n1. Increase awareness of SDG 3, SDG 4, and SDG 13 linkages.\n2. Use Kaggle-hosted SDG datasets to identify priority issues.\n3. Deliver education/campaign activities for ${community}.\n4. Generate Vision 2030 and Vision 2035 alignment evidence.\n\nActivities:\n- Baseline dataset review through Sage Dataset/RAG Agent.\n- Awareness session and campaign material generation.\n- Country/region indicator comparison.\n- Client-ready report and impact score.\n- Final presentation mode for stakeholders.\n\nExpected Outcomes:\n- Better SDG literacy.\n- Practical health and climate awareness.\n- Education-oriented community action.\n- Exportable report for client/teacher review.\n\nMonitoring Indicators:\n- Participation count.\n- Awareness quiz improvement.\n- SDG impact score.\n- Vision alignment score.\n- Report completion status.`;
}

function downloadText(filename, content){
  const blob=new Blob([content],{type:'text/markdown;charset=utf-8'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

let deckIndex=0;
const deck=[
  ['Sage SDGs AI','Hello, I am Sage SDGs AI — a mega multi-agent for SDG 3 health, SDG 4 education, and SDG 13 climate action.'],
  ['Dataset-Backed Intelligence','I use a Kaggle-ready dataset foundation, RAG retrieval, SDG selector logic, dataset routing, and evidence-based response design.'],
  ['Multi-Agent System','My internal modules include Health Agent, Education Agent, Climate Agent, Data Analyst Agent, Report Writer Agent, Safety Reviewer, Vision Agent, and Credential Agent.'],
  ['Confidential Client Layer','I support User, Admin, and Client dashboards with role-aware workspace concepts, saved memory, private reports, and environment-safe API keys.'],
  ['Voice and Command Mode','Users can speak to me, command me with Sage-style instructions, generate reports, run project blueprints, and export results.'],
  ['Vision Alignment','I connect project outputs with SDGs, Vision 2030, and Vision 2035 for policy, academic, and client-ready impact.']
];
function showSlide(i=0){
  deckIndex=(i+deck.length)%deck.length; const [title,body]=deck[deckIndex];
  let ov=document.querySelector('.presentationOverlay');
  if(!ov){ ov=document.createElement('div'); ov.className='presentationOverlay'; document.body.appendChild(ov); }
  ov.innerHTML=`<div class="presentationCard"><h2>${escapeHtml(title)}</h2><p>${escapeHtml(body)}</p><div class="presentationControls"><button id="prevSlide">Previous</button><button id="speakSlide">Speak</button><button id="nextSlide">Next</button><button id="closeSlide">Close</button></div></div>`;
  $('prevSlide').onclick=()=>showSlide(deckIndex-1); $('nextSlide').onclick=()=>showSlide(deckIndex+1); $('closeSlide').onclick=()=>{window.speechSynthesis?.cancel(); ov.remove();}; $('speakSlide').onclick=()=>speak(title+'. '+body); speak(title+'. '+body);
}

function attachV6(){
  $('voiceDemoBtn')?.addEventListener('click',()=>{ $('agent')?.scrollIntoView({behavior:'smooth'}); speak('Hello, I am Sage SDGs AI. Voice conversation mode is ready. You can use the microphone button or type a Sage command.'); });
  $('ragStatusBtn')?.addEventListener('click', async()=>{ try{ const r=await fetch(`${API_BASE}/api/health`); const j=await r.json(); alert(`RAG documents: ${j.rag_docs || 'seed ready'}\nKaggle configured: ${j.kaggle_configured}\nNVIDIA configured: ${j.nvidia_key_configured}`); }catch(e){ alert('Backend is not running yet. Local UI RAG structure is included.'); }});
  $('exportReportBtn')?.addEventListener('click',()=>{ const content=`# Sage SDGs AI Exported Report\n\nGenerated from latest agent reply.\n\n## Latest Response\n${lastAiReply}\n\n## SDG Context\nSelected SDG: ${$('insightSdg')?.textContent}\nDataset: ${$('insightDataset')?.textContent}\nCommand: ${$('insightCommand')?.textContent}\n\n## Vision Alignment\nThis report is designed for SDG 3, SDG 4, SDG 13, Vision 2030, and Vision 2035 alignment.`; downloadText('sage-sdgs-ai-report.md', content); });
  $('presentationBtn')?.addEventListener('click',()=>showSlide(0));
  $('scoreBtn')?.addEventListener('click',()=>{ const scores=scoreProject($('scoreProjectInput')?.value||''); renderScore($('scoreOutput'),scores); });
  $('projectBtn')?.addEventListener('click',()=>{ $('projectOutput').textContent=generateBlueprint(); });
  $('monitorBtn')?.addEventListener('click', async()=>{ const el=$('systemMonitor'); try{ const r=await fetch(`${API_BASE}/api/health`); const j=await r.json(); el.textContent=JSON.stringify(j,null,2); }catch(e){ el.textContent='Frontend ready. Start FastAPI backend for live monitor.'; }});
  $('savePromptBtn')?.addEventListener('click',()=>alert('Prompt draft saved locally in prototype. Production admin mode should store this in the secure backend database.'));
}
attachV6();

// Extend submit with safety note by wrapping original listener behavior is not simple here, so add input warning on send click.
$('chatInput')?.addEventListener('input', e=>{ const warn=safetyPrecheck(e.target.value); if(warn){ $('insightRag').textContent='Safety precheck'; } });


// v8 global intelligence upgrades: multilingual, lifecycle, predictive analytics, collaboration
function makeLanguagePrompt(language, text){
  return `Sage SDGs AI multilingual mode (${language}).\n\nOriginal response:\n${text}\n\nInstruction: Provide a clear, culturally respectful ${language} version for SDG users while keeping the meaning professional and project-ready.`;
}
function translateLatestDemo(){
  const lang=$('languageSelect')?.value || 'English';
  const prompt=makeLanguagePrompt(lang,lastAiReply || 'Hello from Sage SDGs AI.');
  const out=$('translationOutput');
  if(out){
    out.value = lang==='English' ? (lastAiReply || 'Sage SDGs AI is ready.') : prompt + '\n\nNote: In live mode, Sage sends this to the AI provider for high-quality translation.';
  }
  $('insightCommand').textContent='multilingual';
}
let lifecycleIndex=1;
function addLifecycleMilestone(){
  const input=$('milestoneInput');
  const text=(input?.value || '').trim() || 'New SDG milestone completed';
  const list=$('milestoneList');
  if(list){ const div=document.createElement('div'); div.textContent=text; list.prepend(div); }
  const steps=[...document.querySelectorAll('#lifecycleSteps .step')];
  if(lifecycleIndex < steps.length-1){
    steps[lifecycleIndex].classList.remove('active'); steps[lifecycleIndex].classList.add('done'); lifecycleIndex++;
    steps[lifecycleIndex].classList.add('active');
  }
  if(input) input.value='';
  $('insightCommand').textContent='lifecycle tracking';
}
function runForecast(){
  const intervention=($('forecastIntervention')?.value || 'SDG intervention').toLowerCase();
  const reach=Math.max(1, Number($('forecastReach')?.value || 100));
  const health=/health|dengue|hygiene|wellbeing|mental|disease|nutrition/.test(intervention) ? 18 : 8;
  const education=/school|education|student|teacher|training|literacy|awareness/.test(intervention) ? 18 : 8;
  const climate=/climate|co2|carbon|flood|heat|environment|resilience/.test(intervention) ? 18 : 8;
  const scale=Math.min(20, Math.round(reach/100));
  const scores={
    'Projected SDG 3 health benefit': Math.min(95, 45+health+scale),
    'Projected SDG 4 learning benefit': Math.min(95, 45+education+scale),
    'Projected SDG 13 climate resilience': Math.min(95, 45+climate+scale),
    'Vision 2030/2035 readiness': Math.min(96, 58+Math.round((health+education+climate)/3)+scale)
  };
  const out=$('forecastOutput');
  if(out){ out.innerHTML=Object.entries(scores).map(([k,v])=>`<div class="forecastMetric"><b>${k}</b> — ${v}%<div class="scoreBar"><span style="width:${v}%"></span></div></div>`).join('')+'<p class="sectionLead">Prototype forecast only. Production forecasting should be calibrated with real historical Kaggle indicators and verified assumptions.</p>'; }
  $('insightCommand').textContent='predictive analytics';
}
function addCollaborator(){
  const name=($('collabName')?.value || 'New collaborator').trim();
  const role=$('collabRole')?.value || 'Contributor';
  const list=$('collabList');
  if(list){ const div=document.createElement('div'); div.innerHTML=`<b>${escapeHtml(name)}</b> — ${escapeHtml(role)} <small>shared workspace access: prototype</small>`; list.prepend(div); }
  $('insightCommand').textContent='collaboration';
}
function attachV8(){
  $('translateDemoBtn')?.addEventListener('click', translateLatestDemo);
  $('addMilestoneBtn')?.addEventListener('click', addLifecycleMilestone);
  $('runForecastBtn')?.addEventListener('click', runForecast);
  $('addCollaboratorBtn')?.addEventListener('click', addCollaborator);
  $('forecastBtn')?.addEventListener('click', runForecast);
  $('collabBtn')?.addEventListener('click', addCollaborator);
  $('languageSelect')?.addEventListener('change', translateLatestDemo);
}
attachV8();

// v10: Experience Solver demo trigger
$('experienceDemoBtn')?.addEventListener('click',()=>{
  $('agent')?.scrollIntoView({behavior:'smooth'});
  $('chatInput').value='/solve climate-health school absenteeism problem in Pakistan';
  $('chatForm').requestSubmit();
});

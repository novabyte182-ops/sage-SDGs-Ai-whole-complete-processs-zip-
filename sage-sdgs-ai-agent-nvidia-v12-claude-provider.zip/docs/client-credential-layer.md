# Client Credential Layer

Prototype demo login supports user, admin, and client roles. It stores demo tokens in SQLite. Replace with production auth before deployment.

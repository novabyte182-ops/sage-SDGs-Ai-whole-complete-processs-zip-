# RAG and Memory

The backend retrieves local SDG evidence from data/rag_seed.json and stores client/project memory in SQLite. Kaggle ingestion is prepared in scripts/kaggle_ingest.py.

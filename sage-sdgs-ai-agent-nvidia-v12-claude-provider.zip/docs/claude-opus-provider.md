# Claude Opus 4.7 Fast Provider

Sage SDGs AI v12 adds an optional OpenRouter provider for the model:

`anthropic/claude-opus-4.7-fast`

## Environment variable

Set this only in the backend/server environment:

```bash
OPENROUTER_API_KEY=your_openrouter_key_here
```

Do not put real keys in `frontend/index.html`, `frontend/app.js`, screenshots, public GitHub repositories, or ZIP files shared with others.

## Backend route

The existing `/api/agent` route accepts `provider: "claude-opus"` and routes the request to OpenRouter. If the key is missing, Sage SDGs AI returns a safe demo response so the website still chats.

## Security note

Any real key previously shared in a chat should be revoked/rotated before use.

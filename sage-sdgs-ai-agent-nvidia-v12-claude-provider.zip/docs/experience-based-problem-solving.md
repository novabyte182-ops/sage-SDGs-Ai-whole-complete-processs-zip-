# v10 Experience-Based Problem Solving

Sage SDGs AI now includes an experience-based problem solver. It is designed to make the agent solve problems like a project partner instead of only answering questions.

## Added behavior

- New command: `/solve`
- New command: `/experience`
- New UI section: Experience-Based Problem Solver
- New backend endpoint: `/api/experience-solver`
- New data file: `data/experience_playbooks.json`

## How it works

1. Reads the user's problem.
2. Detects whether the issue is health, education, climate, data/policy, or cross-SDG.
3. Matches the issue to an experience playbook.
4. Identifies likely root causes.
5. Recommends practical next actions.
6. Suggests next commands such as `/project`, `/score`, `/campaign`, `/report`, or `/vision`.

## Example command

`/solve climate-health school absenteeism problem in Pakistan`

The output includes the problem pattern, relevant SDGs, dataset route, experience lesson, action plan, and next decision.

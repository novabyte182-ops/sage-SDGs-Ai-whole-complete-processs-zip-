# Sage SDGs AI Conversational Voice

This prototype includes a browser-based conversational voice layer for Sage SDGs AI.

## What it does
- Speaks AI agent replies aloud using the browser Web Speech API.
- Lets the user turn auto-speak on or off.
- Includes a voice selector using available system/browser voices.
- Includes rate and pitch controls for a clearer professional sound.
- Includes Speak Latest and Stop buttons.

## Why this approach
No external copyrighted voice file is embedded, and no text-to-speech API key is exposed in frontend code. The prototype is safe to deploy as a frontend/backend project.

## Future upgrade
A premium TTS provider can be added later through a secure backend route, using environment variables only. Do not place paid voice API keys in frontend JavaScript.

# Kimi K2.6 Provider

This update adds support for the NVIDIA-hosted `moonshotai/kimi-k2.6` model using the direct HTTP chat completions pattern.

The implementation is in `backend/server.py` as `call_kimi()`. It uses:

- endpoint: `https://integrate.api.nvidia.com/v1/chat/completions`
- model: `moonshotai/kimi-k2.6`
- max tokens: `16384`
- temperature: `1.00`
- top_p: `1.00`
- thinking: enabled through `chat_template_kwargs`

No actual API key is included. Add the key only as a backend environment variable:

```env
NVIDIA_API_KEY=your_real_key_here
```

The frontend provider selector now includes **Kimi K2.6**.

# Voice Assistant Mode

The frontend includes browser text-to-speech, speech recognition where supported, emotion presets, your uploaded sample preview, and controls for voice, pitch, and rate. Exact cloned voice output requires a licensed provider.

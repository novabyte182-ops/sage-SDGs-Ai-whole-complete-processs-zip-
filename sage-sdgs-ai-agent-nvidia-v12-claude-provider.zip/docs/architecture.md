# Sage SDGs AI Architecture

User query → SDG Selector → Dataset Selector → RAG Retrieval → Multi-Agent Reasoning → Memory Update → Safety Review → Final Response.

## Modules
- Health Agent: SDG 3
- Education Agent: SDG 4
- Climate Agent: SDG 13
- Data Analyst Agent
- Report Writer Agent
- Safety Reviewer Agent
- Vision Alignment Agent
- Dataset/RAG Agent

## Secure API Pattern
Frontend calls `/api/agent`. Backend calls NVIDIA endpoint using `NVIDIA_API_KEY` from environment variables. Real API keys must never be placed in frontend code.

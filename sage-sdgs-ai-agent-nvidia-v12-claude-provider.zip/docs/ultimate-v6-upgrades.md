# Sage SDGs AI — Ultimate v6 Upgrades

This version adds the advanced Jarvis-style modules requested after v5.

## Added

- Real voice conversation controls with microphone input, text-to-speech, emotion presets, interruption/stop, and uploaded voice sample preview.
- Real Kaggle RAG readiness with Kaggle status endpoint, ingestion script, dataset manager, RAG seed file, and env-variable credential structure.
- Report export system for Markdown/HTML-style project outputs.
- Client workspace layer for confidential role-based User/Admin/Client work.
- SDG impact scoring engine across SDG 3, SDG 4, SDG 13, feasibility, and Vision 2030/2035 alignment.
- Data visualization dashboard concepts using KPI cards and score bars.
- Admin AI control panel concept for prompt control, API/RAG monitor, and safety management.
- Presentation mode where Sage SDGs AI introduces the project like a defense assistant.
- SDG 3 emergency and safety mode for urgent/unsafe health topics.
- SDG project generator for country, community, SDG, duration, objectives, activities, outputs, and monitoring indicators.
- Cross-SDG knowledge graph showing climate-health-education-Vision relationships.

## New backend endpoints

- `GET /api/kaggle/status`
- `POST /api/impact-score`
- `POST /api/project-blueprint`
- `GET /api/presentation-script`
- `POST /api/export-report`

## Important

No real API keys are stored in the project. Add them through environment variables only.

```env
NVIDIA_API_KEY=your_key_here
KAGGLE_USERNAME=your_username
KAGGLE_KEY=your_key
```

Exact cloned voice generation requires a licensed voice provider. The uploaded voice sample is included only for preview and future provider-ready integration.

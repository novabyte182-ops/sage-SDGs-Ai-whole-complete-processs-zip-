const API_BASE = window.SAGE_API_BASE || ((window.location.protocol === 'file:' || window.location.port === '8080') ? 'http://localhost:8000' : window.location.origin);
let history = [];
let taskMode = 'conversation';
let currentUser = null;
let datasets = [];
let availableVoices = [];
let lastAiReply = 'Hello, I’m Sage SDGs AI — your intelligent multi-agent assistant for Sustainable Development Goals 3, 4, and 13. I am designed to support health and well-being, quality education, and climate action through dataset-backed insights, RAG-style retrieval, memory, SDG impact analysis, project generation, report support, and Vision 2030/2035 alignment. You can ask me to compare countries, generate reports, design awareness campaigns, create SDG projects, explain dataset evidence, or prepare presentation-ready recommendations.';

const $ = id => document.getElementById(id);
const escapeHtml = s => (s || '').replace(/[&<>\"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function addMsg(role, text){ const wrap=document.createElement('div'); wrap.className=`msg ${role}`; wrap.innerHTML=`<b>${role==='ai'?'Sage SDGs AI':'You'}</b><p>${escapeHtml(text)}</p>`; $('messages').appendChild(wrap); $('messages').scrollTop=1e9; return wrap.querySelector('p'); }
function detectCommand(text){ const t=text.trim().toLowerCase(); if(t.startsWith('/report')) return 'report'; if(t.startsWith('/campaign')) return 'campaign'; if(t.startsWith('/compare')) return 'compare'; if(t.startsWith('/vision')) return 'vision'; if(t.startsWith('/remember')) return 'remember'; if(t.startsWith('/dataset')) return 'dataset'; if(t.startsWith('/project')) return 'project'; if(t.startsWith('/score')) return 'score'; if(t.startsWith('/presentation')) return 'presentation'; if(t.startsWith('/graph')) return 'graph'; if(t.startsWith('/emergency')) return 'emergency'; if(t.startsWith('sage,')) return 'command'; return taskMode; }
function routeDataset(text, sdg){ const low=text.toLowerCase(); if(sdg==='SDG 4'||/education|school|literacy|teacher|learning|student/.test(low))return 'World Bank Education Statistics / EdStats'; if(sdg==='SDG 13'||/climate|co2|emission|carbon|heat|flood|greenhouse/.test(low))return 'Climate Watch + CO₂/GHG'; if(sdg==='SDG 3'||/health|disease|wellbeing|mortality|mental|maternal|vaccine/.test(low))return 'World Health Statistics Report by WHO'; return 'World Bank SDGs + WDI'; }
async function loadDatasets(){ try{ const r=await fetch('../data/datasets.json'); datasets=await r.json(); const grid=$('datasetGrid'); const select=$('datasetSelect'); grid.innerHTML=''; select.innerHTML='<option value="auto">Auto dataset routing</option>'; datasets.forEach(d=>{ const card=document.createElement('article'); card.className='datasetCard'; card.innerHTML=`<h3>${escapeHtml(d.name)}</h3><div>${(d.sdgs||[]).map(s=>`<span class="tag">${s}</span>`).join('')}<span class="tag ${d.type==='Core'?'core':''}">${d.type}</span></div><p>${escapeHtml(d.use)}</p>`; grid.appendChild(card); const opt=document.createElement('option'); opt.value=d.name; opt.textContent=d.name; select.appendChild(opt); }); }catch(e){ console.warn(e); } }
loadDatasets();

async function checkApi(){ try{ const r=await fetch(`${API_BASE}/api/health`); const j=await r.json(); $('apiStatus').textContent = j.nvidia_key_configured ? 'API: Live' : 'API: Demo'; }catch(e){ $('apiStatus').textContent='API: Frontend demo'; } }
checkApi();

function renderDashboard(view){ const el=$('dashboardView'); const role=currentUser?.role || 'guest'; const locked = (view==='admin' && role!=='admin') || (view==='client' && !['client','admin'].includes(role)); if(locked){ el.innerHTML=`<h3>${view.toUpperCase()} view locked</h3><p class="sectionLead">Sign in with the correct demo credential to preview this confidential dashboard layer.</p>`; return; }
 const copy={user:'Ask questions, use voice, generate SDG reports, compare countries, and save project memory.', admin:'Monitor APIs, datasets, RAG status, safety logs, users, and Kaggle refresh schedules.', client:'Manage organization projects, private reports, Vision 2030/2035 scores, and export-ready deliverables.'}[view];
 el.innerHTML=`<h3>${view[0].toUpperCase()+view.slice(1)} Dashboard</h3><p class="sectionLead">${copy}</p><div class="kpiGrid"><div class="kpi"><b>3</b><span>Core SDGs</span></div><div class="kpi"><b>14</b><span>Dataset Layers</span></div><div class="kpi"><b>8</b><span>Agent Modules</span></div><div class="kpi"><b>2</b><span>Vision Frameworks</span></div></div>`; }
document.querySelectorAll('.viewBtn').forEach(b=>b.addEventListener('click',()=>renderDashboard(b.dataset.view)));
renderDashboard('user');

$('loginBtn').addEventListener('click', async()=>{ try{ const r=await fetch(`${API_BASE}/api/login`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email:$('emailInput').value, password:$('passwordInput').value, role:$('roleSelect').value})}); const j=await r.json(); if(!r.ok) throw new Error(j.detail || 'Login failed'); currentUser=j.user; localStorage.setItem('sage_token', j.token); $('loginStatus').textContent=`Signed in as ${j.user.role}: ${j.user.email}`; $('insightRole').textContent=j.user.role; $('insightMemory').textContent='Memory DB active'; }catch(err){ $('loginStatus').textContent=err.message; }});

document.querySelectorAll('.mode').forEach(btn=>btn.addEventListener('click',()=>{ document.querySelectorAll('.mode').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); taskMode=btn.dataset.mode; $('insightCommand').textContent=taskMode; }));
document.querySelectorAll('.quickPrompts button').forEach(btn=>btn.addEventListener('click',()=>{ $('chatInput').value=btn.textContent; $('chatForm').requestSubmit(); }));

function loadVoices(){ const select=$('voiceSelect'); if(!select || !('speechSynthesis' in window)) return; availableVoices=window.speechSynthesis.getVoices(); const preferred=availableVoices.filter(v=>/en-|English/i.test(v.lang+' '+v.name)).sort((a,b)=>{ const score=v=>/natural|premium|enhanced|neural|google|microsoft|zira|samantha|aria|jenny/i.test(v.name)?0:1; return score(a)-score(b) || a.name.localeCompare(b.name); }); const voices=preferred.length?preferred:availableVoices; select.innerHTML=voices.map(v=>`<option value="${availableVoices.indexOf(v)}">${v.name} — ${v.lang}</option>`).join('') || '<option>No browser voices found</option>'; }
function emotionSettings(){ const e=$('emotionSelect')?.value || 'professional'; const map={professional:[0.95,1.0],warm:[0.92,1.05],confident:[0.98,0.95],empathetic:[0.86,0.98],energetic:[1.08,1.08]}; return map[e] || map.professional; }
function cleanForSpeech(text){ return (text||'').replace(/[#*_`>]/g,'').replace(/https?:\/\/\S+/g,'link').replace(/\s+/g,' ').trim(); }
function speak(text){ if(!text || !('speechSynthesis' in window)) return; window.speechSynthesis.cancel(); const u=new SpeechSynthesisUtterance(cleanForSpeech(text)); const selected=availableVoices[Number($('voiceSelect')?.value)]; if(selected) u.voice=selected; const [er,ep]=emotionSettings(); u.rate=Number($('voiceRate')?.value || er); u.pitch=Number($('voicePitch')?.value || ep); u.volume=1; u.onstart=()=>{document.body.classList.add('speaking'); $('insightVoice').textContent='Speaking';}; u.onend=()=>{document.body.classList.remove('speaking'); $('insightVoice').textContent='TTS ready';}; u.onerror=()=>document.body.classList.remove('speaking'); window.speechSynthesis.speak(u); }
function maybeSpeak(text){ lastAiReply=text||lastAiReply; if($('voiceAuto')?.checked) speak(lastAiReply); }
if('speechSynthesis' in window){ loadVoices(); window.speechSynthesis.onvoiceschanged=loadVoices; }
$('speakLast').addEventListener('click',()=>speak(lastAiReply));
$('stopVoice').addEventListener('click',()=>{ if('speechSynthesis' in window) window.speechSynthesis.cancel(); document.body.classList.remove('speaking'); });
$('previewMyVoice').addEventListener('click',()=>{ const a=$('userVoiceAudio'); if(a){ a.currentTime=0; a.play(); $('insightVoice').textContent='Playing uploaded sample'; }});
$('emotionSelect').addEventListener('change',()=>{ const [r,p]=emotionSettings(); $('voiceRate').value=r; $('voicePitch').value=p; });

let recognition=null; function setupRecognition(){ const SR=window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR) return null; const rec=new SR(); rec.lang='en-US'; rec.interimResults=false; rec.continuous=false; rec.onstart=()=>{$('insightVoice').textContent='Listening';}; rec.onresult=e=>{ const transcript=e.results[0][0].transcript; $('chatInput').value=transcript; $('chatForm').requestSubmit();}; rec.onerror=()=>{$('insightVoice').textContent='Voice input unavailable';}; rec.onend=()=>{ if($('insightVoice').textContent==='Listening') $('insightVoice').textContent='TTS ready';}; return rec; }
$('startListening').addEventListener('click',()=>{ recognition=recognition||setupRecognition(); if(recognition) recognition.start(); else alert('Speech recognition is not supported in this browser. Use Chrome/Edge for voice input.'); });

$('chatForm').addEventListener('submit', async(e)=>{ e.preventDefault(); const input=$('chatInput'); const text=input.value.trim(); if(!text) return; input.value=''; addMsg('user', text); history.push({role:'user', content:text}); const sdg=$('sdgSelect').value; const country=$('countryInput').value; const ds=$('datasetSelect').value==='auto'?routeDataset(text,sdg):$('datasetSelect').value; const command=detectCommand(text); $('insightSdg').textContent=sdg; $('insightDataset').textContent=ds; $('insightCommand').textContent=command; $('insightRag').textContent='Retrieving'; const aiP=addMsg('ai','Thinking as Sage SDGs AI mega agent...'); try{ const token=localStorage.getItem('sage_token') || ''; const r=await fetch(`${API_BASE}/api/agent`,{method:'POST',headers:{'Content-Type':'application/json','Authorization': token?`Bearer ${token}`:''},body:JSON.stringify({messages:history,selected_sdg:sdg,selected_country:country,selected_dataset:ds,task_mode:command,stream:false,provider:$('providerSelect')?.value||'deepseek', client_id: currentUser?.client_id || 'demo-client'})}); const j=await r.json(); aiP.textContent=j.response || 'No response returned.'; history.push({role:'assistant', content:aiP.textContent}); maybeSpeak(aiP.textContent); $('insightDataset').textContent=j.selected_dataset||ds; $('insightRag').textContent=j.mode==='live'?'Live NVIDIA + RAG context':'Demo RAG + local seed'; $('insightMemory').textContent=j.memory_status || 'Short-term + selector'; if($('voiceListenAuto').checked) setTimeout(()=>$('startListening').click(), 1200); }catch(err){ aiP.textContent='I am Sage SDGs AI. The frontend is ready, but the backend is not running yet. Start it with: uvicorn backend.server:app --host 0.0.0.0 --port 8000 --reload. After setting NVIDIA_API_KEY, I will answer through the selected NVIDIA model.'; $('insightRag').textContent='Backend offline'; maybeSpeak(aiP.textContent); } });


// v6 Ultimate Jarvis-style additions
const emergencyTerms = /(chest pain|can't breathe|cannot breathe|suicide|self harm|overdose|unconscious|severe bleeding|stroke|heart attack|emergency|dangerous medicine|prescribe)/i;
function safetyPrecheck(text){
  if(!emergencyTerms.test(text)) return null;
  return "Safety alert: I can provide public-health education, but this may be urgent. If there is immediate danger, severe symptoms, self-harm risk, breathing difficulty, chest pain, overdose, unconsciousness, or severe bleeding, contact local emergency services or a qualified medical professional immediately. I will avoid diagnosis or prescribing and keep guidance safe.";
}

function scoreProject(text){
  const low=(text||'').toLowerCase();
  let sdg3=35, sdg4=35, sdg13=35;
  if(/health|dengue|mental|disease|wellbeing|maternal|nutrition|hygiene/.test(low)) sdg3+=45;
  if(/education|school|student|teacher|literacy|training|awareness|university/.test(low)) sdg4+=42;
  if(/climate|co2|carbon|flood|heat|resilience|environment|emission/.test(low)) sdg13+=42;
  const feasibility = Math.min(95, 55 + (low.length>30?18:8) + (/community|campaign|training|school|local/.test(low)?12:0));
  const vision = Math.round((sdg3+sdg4+sdg13+feasibility)/4);
  return {sdg3:Math.min(98,sdg3), sdg4:Math.min(98,sdg4), sdg13:Math.min(98,sdg13), feasibility, vision};
}
function renderScore(target, scores){
  target.innerHTML = Object.entries(scores).map(([k,v])=>`<div><b>${k.toUpperCase().replace('SDG','SDG ')}</b> — ${v}%<div class="scoreBar"><span style="width:${v}%"></span></div></div>`).join('') + '<p class="sectionLead">Interpretation: this is a prototype scoring model. Production scoring should use real indicators from Kaggle-hosted datasets and client-specific criteria.</p>';
}
function generateBlueprint(){
  const country=$('projectCountry')?.value||'Pakistan'; const community=$('projectCommunity')?.value||'community'; const sdg=$('projectSdg')?.value||'Cross-SDG'; const duration=$('projectDuration')?.value||'8 weeks';
  return `Sage SDGs AI Project Blueprint\n\nTitle: Integrated ${sdg} Action Program for ${community} in ${country}\n\nGoal: Improve health, education, and climate resilience through a data-backed community intervention.\n\nDuration: ${duration}\n\nObjectives:\n1. Increase awareness of SDG 3, SDG 4, and SDG 13 linkages.\n2. Use Kaggle-hosted SDG datasets to identify priority issues.\n3. Deliver education/campaign activities for ${community}.\n4. Generate Vision 2030 and Vision 2035 alignment evidence.\n\nActivities:\n- Baseline dataset review through Sage Dataset/RAG Agent.\n- Awareness session and campaign material generation.\n- Country/region indicator comparison.\n- Client-ready report and impact score.\n- Final presentation mode for stakeholders.\n\nExpected Outcomes:\n- Better SDG literacy.\n- Practical health and climate awareness.\n- Education-oriented community action.\n- Exportable report for client/teacher review.\n\nMonitoring Indicators:\n- Participation count.\n- Awareness quiz improvement.\n- SDG impact score.\n- Vision alignment score.\n- Report completion status.`;
}

function downloadText(filename, content){
  const blob=new Blob([content],{type:'text/markdown;charset=utf-8'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

let deckIndex=0;
const deck=[
  ['Sage SDGs AI','Hello, I am Sage SDGs AI — a mega multi-agent for SDG 3 health, SDG 4 education, and SDG 13 climate action.'],
  ['Dataset-Backed Intelligence','I use a Kaggle-ready dataset foundation, RAG retrieval, SDG selector logic, dataset routing, and evidence-based response design.'],
  ['Multi-Agent System','My internal modules include Health Agent, Education Agent, Climate Agent, Data Analyst Agent, Report Writer Agent, Safety Reviewer, Vision Agent, and Credential Agent.'],
  ['Confidential Client Layer','I support User, Admin, and Client dashboards with role-aware workspace concepts, saved memory, private reports, and environment-safe API keys.'],
  ['Voice and Command Mode','Users can speak to me, command me with Sage-style instructions, generate reports, run project blueprints, and export results.'],
  ['Vision Alignment','I connect project outputs with SDGs, Vision 2030, and Vision 2035 for policy, academic, and client-ready impact.']
];
function showSlide(i=0){
  deckIndex=(i+deck.length)%deck.length; const [title,body]=deck[deckIndex];
  let ov=document.querySelector('.presentationOverlay');
  if(!ov){ ov=document.createElement('div'); ov.className='presentationOverlay'; document.body.appendChild(ov); }
  ov.innerHTML=`<div class="presentationCard"><h2>${escapeHtml(title)}</h2><p>${escapeHtml(body)}</p><div class="presentationControls"><button id="prevSlide">Previous</button><button id="speakSlide">Speak</button><button id="nextSlide">Next</button><button id="closeSlide">Close</button></div></div>`;
  $('prevSlide').onclick=()=>showSlide(deckIndex-1); $('nextSlide').onclick=()=>showSlide(deckIndex+1); $('closeSlide').onclick=()=>{window.speechSynthesis?.cancel(); ov.remove();}; $('speakSlide').onclick=()=>speak(title+'. '+body); speak(title+'. '+body);
}

function attachV6(){
  $('voiceDemoBtn')?.addEventListener('click',()=>{ $('agent')?.scrollIntoView({behavior:'smooth'}); speak('Hello, I am Sage SDGs AI. Voice conversation mode is ready. You can use the microphone button or type a Sage command.'); });
  $('ragStatusBtn')?.addEventListener('click', async()=>{ try{ const r=await fetch(`${API_BASE}/api/health`); const j=await r.json(); alert(`RAG documents: ${j.rag_docs || 'seed ready'}\nKaggle configured: ${j.kaggle_configured}\nNVIDIA configured: ${j.nvidia_key_configured}`); }catch(e){ alert('Backend is not running yet. Local UI RAG structure is included.'); }});
  $('exportReportBtn')?.addEventListener('click',()=>{ const content=`# Sage SDGs AI Exported Report\n\nGenerated from latest agent reply.\n\n## Latest Response\n${lastAiReply}\n\n## SDG Context\nSelected SDG: ${$('insightSdg')?.textContent}\nDataset: ${$('insightDataset')?.textContent}\nCommand: ${$('insightCommand')?.textContent}\n\n## Vision Alignment\nThis report is designed for SDG 3, SDG 4, SDG 13, Vision 2030, and Vision 2035 alignment.`; downloadText('sage-sdgs-ai-report.md', content); });
  $('presentationBtn')?.addEventListener('click',()=>showSlide(0));
  $('scoreBtn')?.addEventListener('click',()=>{ const scores=scoreProject($('scoreProjectInput')?.value||''); renderScore($('scoreOutput'),scores); });
  $('projectBtn')?.addEventListener('click',()=>{ $('projectOutput').textContent=generateBlueprint(); });
  $('monitorBtn')?.addEventListener('click', async()=>{ const el=$('systemMonitor'); try{ const r=await fetch(`${API_BASE}/api/health`); const j=await r.json(); el.textContent=JSON.stringify(j,null,2); }catch(e){ el.textContent='Frontend ready. Start FastAPI backend for live monitor.'; }});
  $('savePromptBtn')?.addEventListener('click',()=>alert('Prompt draft saved locally in prototype. Production admin mode should store this in the secure backend database.'));
}
attachV6();

// Extend submit with safety note by wrapping original listener behavior is not simple here, so add input warning on send click.
$('chatInput')?.addEventListener('input', e=>{ const warn=safetyPrecheck(e.target.value); if(warn){ $('insightRag').textContent='Safety precheck'; } });


// v8 global intelligence upgrades: multilingual, lifecycle, predictive analytics, collaboration
function makeLanguagePrompt(language, text){
  return `Sage SDGs AI multilingual mode (${language}).\n\nOriginal response:\n${text}\n\nInstruction: Provide a clear, culturally respectful ${language} version for SDG users while keeping the meaning professional and project-ready.`;
}
function translateLatestDemo(){
  const lang=$('languageSelect')?.value || 'English';
  const prompt=makeLanguagePrompt(lang,lastAiReply || 'Hello from Sage SDGs AI.');
  const out=$('translationOutput');
  if(out){
    out.value = lang==='English' ? (lastAiReply || 'Sage SDGs AI is ready.') : prompt + '\n\nNote: In live mode, Sage sends this to the AI provider for high-quality translation.';
  }
  $('insightCommand').textContent='multilingual';
}
let lifecycleIndex=1;
function addLifecycleMilestone(){
  const input=$('milestoneInput');
  const text=(input?.value || '').trim() || 'New SDG milestone completed';
  const list=$('milestoneList');
  if(list){ const div=document.createElement('div'); div.textContent=text; list.prepend(div); }
  const steps=[...document.querySelectorAll('#lifecycleSteps .step')];
  if(lifecycleIndex < steps.length-1){
    steps[lifecycleIndex].classList.remove('active'); steps[lifecycleIndex].classList.add('done'); lifecycleIndex++;
    steps[lifecycleIndex].classList.add('active');
  }
  if(input) input.value='';
  $('insightCommand').textContent='lifecycle tracking';
}
function runForecast(){
  const intervention=($('forecastIntervention')?.value || 'SDG intervention').toLowerCase();
  const reach=Math.max(1, Number($('forecastReach')?.value || 100));
  const health=/health|dengue|hygiene|wellbeing|mental|disease|nutrition/.test(intervention) ? 18 : 8;
  const education=/school|education|student|teacher|training|literacy|awareness/.test(intervention) ? 18 : 8;
  const climate=/climate|co2|carbon|flood|heat|environment|resilience/.test(intervention) ? 18 : 8;
  const scale=Math.min(20, Math.round(reach/100));
  const scores={
    'Projected SDG 3 health benefit': Math.min(95, 45+health+scale),
    'Projected SDG 4 learning benefit': Math.min(95, 45+education+scale),
    'Projected SDG 13 climate resilience': Math.min(95, 45+climate+scale),
    'Vision 2030/2035 readiness': Math.min(96, 58+Math.round((health+education+climate)/3)+scale)
  };
  const out=$('forecastOutput');
  if(out){ out.innerHTML=Object.entries(scores).map(([k,v])=>`<div class="forecastMetric"><b>${k}</b> — ${v}%<div class="scoreBar"><span style="width:${v}%"></span></div></div>`).join('')+'<p class="sectionLead">Prototype forecast only. Production forecasting should be calibrated with real historical Kaggle indicators and verified assumptions.</p>'; }
  $('insightCommand').textContent='predictive analytics';
}
function addCollaborator(){
  const name=($('collabName')?.value || 'New collaborator').trim();
  const role=$('collabRole')?.value || 'Contributor';
  const list=$('collabList');
  if(list){ const div=document.createElement('div'); div.innerHTML=`<b>${escapeHtml(name)}</b> — ${escapeHtml(role)} <small>shared workspace access: prototype</small>`; list.prepend(div); }
  $('insightCommand').textContent='collaboration';
}
function attachV8(){
  $('translateDemoBtn')?.addEventListener('click', translateLatestDemo);
  $('addMilestoneBtn')?.addEventListener('click', addLifecycleMilestone);
  $('runForecastBtn')?.addEventListener('click', runForecast);
  $('addCollaboratorBtn')?.addEventListener('click', addCollaborator);
  $('forecastBtn')?.addEventListener('click', runForecast);
  $('collabBtn')?.addEventListener('click', addCollaborator);
  $('languageSelect')?.addEventListener('change', translateLatestDemo);
}
attachV8();

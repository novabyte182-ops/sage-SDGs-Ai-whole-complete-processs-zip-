# NVIDIA API Integration for Sage SDGs AI

This prototype supports two NVIDIA API modes from the backend only. Never place real API keys inside frontend JavaScript or public files.

## Environment Variable

```bash
NVIDIA_API_KEY=your_real_key_here
```

## Provider 1: DeepSeek through OpenAI-compatible SDK

- Base URL: `https://integrate.api.nvidia.com/v1`
- Model: `deepseek-ai/deepseek-v4-flash`
- Backend function: `call_deepseek_openai` / `stream_deepseek_openai`

## Provider 2: Mistral through direct requests

- URL: `https://integrate.api.nvidia.com/v1/chat/completions`
- Model: `mistralai/mistral-medium-3.5-128b`
- Backend function: `call_mistral_requests` / `stream_mistral_requests`

The user-provided Mistral request pattern has been added safely in `backend/server.py`. The Authorization header uses `Bearer {NVIDIA_API_KEY}` from server environment variables only.

## Run Locally

```bash
cd backend
pip install -r requirements.txt
export NVIDIA_API_KEY=your_real_key_here
uvicorn server:app --host 0.0.0.0 --port 8000 --reload
```

Then open `frontend/index.html`.

## API Request Example

```json
{
  "messages": [{"role":"user","content":"Create an SDG 3 and SDG 13 project idea for Pakistan."}],
  "selected_sdg": "auto",
  "selected_country": "Pakistan",
  "task_mode": "report",
  "provider": "mistral",
  "stream": false
}
```
